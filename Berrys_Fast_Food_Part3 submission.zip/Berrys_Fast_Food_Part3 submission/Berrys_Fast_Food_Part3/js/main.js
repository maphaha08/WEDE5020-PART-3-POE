/* Berry's Fast Food - Part 3 JavaScript enhancements */
document.addEventListener('DOMContentLoaded', () => {

  // Live South African digital clock
const clock = document.getElementById("digital-clock");

function updateClock() {
    if (!clock) return;

    const now = new Date();

    clock.textContent = new Intl.DateTimeFormat("en-ZA", {
        timeZone: "Africa/Johannesburg",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hourCycle: "h23"
    }).format(now);
}

if (clock) {
    updateClock();
    setInterval(updateClock, 1000);
}
  // Reveal selected content as it enters the viewport (with reduced-motion support).
  const revealTargets = document.querySelectorAll(
    '.menu-item, .gallery-item, .content-section, .feature-card'
  );
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    revealTargets.forEach((element) => element.classList.add('js-reveal'));
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealTargets.forEach((element) => revealObserver.observe(element));
  } else {
    revealTargets.forEach((element) => element.classList.add('is-visible'));
  }

  // Accessible accordion interactions and DOM updates.
  document.querySelectorAll('.accordion-trigger').forEach((trigger) => {
    trigger.addEventListener('click', () => {
      const panel = trigger.nextElementSibling;
      const expanded = trigger.getAttribute('aria-expanded') === 'true';
      trigger.setAttribute('aria-expanded', String(!expanded));
      panel.hidden = expanded;
      const symbol = trigger.querySelector('span');
      if (symbol) symbol.textContent = expanded ? '＋' : '−';
    });
  });

  // Search, filter and sort menu items dynamically.
  const search = document.querySelector('#menu-search');
  const category = document.querySelector('#menu-category');
  const sort = document.querySelector('#menu-sort');
  const menuGrid = document.querySelector('#menu-grid');
  if (menuGrid && search && category && sort) {
    const items = [...menuGrid.querySelectorAll('.menu-item')];
    const updateMenu = () => {
      const term = search.value.trim().toLowerCase();
      const chosen = category.value;
      const ordered = [...items].sort((a, b) => {
        if (sort.value === 'az') return a.dataset.name.localeCompare(b.dataset.name);
        if (sort.value === 'za') return b.dataset.name.localeCompare(a.dataset.name);
        return items.indexOf(a) - items.indexOf(b);
      });
      let visible = 0;
      ordered.forEach((item) => {
        const matches = item.dataset.name.toLowerCase().includes(term) && (chosen === 'all' || item.dataset.category === chosen);
        item.hidden = !matches;
        if (matches) { visible += 1; menuGrid.appendChild(item); }
      });
      const count = document.querySelector('#menu-count');
      if (count) count.textContent = `Showing ${visible} of ${items.length} menu items`;
    };
    [search, category, sort].forEach((control) => control.addEventListener('input', updateMenu));
    [category, sort].forEach((control) => control.addEventListener('change', updateMenu));
  }

  // Gallery lightbox: click an image to enlarge; close with button, backdrop or Escape.
  const lightbox = document.querySelector('#lightbox');
  if (lightbox) {
    const largeImage = document.querySelector('#lightbox-image');
    const caption = document.querySelector('#lightbox-caption');
    const close = lightbox.querySelector('.lightbox-close');
    document.querySelectorAll('.gallery-item img').forEach((image) => {
      image.tabIndex = 0;
      image.setAttribute('role', 'button');
      image.setAttribute('aria-label', `Enlarge ${image.alt}`);
      const open = () => {
        largeImage.src = image.currentSrc || image.src;
        largeImage.alt = image.alt;
        caption.textContent = image.closest('figure').querySelector('figcaption')?.textContent || image.alt;
        lightbox.hidden = false;
        close.focus();
      };
      image.addEventListener('click', open);
      image.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); } });
    });
    const closeLightbox = () => { lightbox.hidden = true; largeImage.src = ''; };
    close.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (event) => { if (event.target === lightbox) closeLightbox(); });
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && !lightbox.hidden) closeLightbox(); });
  }

  // AJAX form submission and client-side validation. FormSubmit must be activated
  // by the recipient on first use before it can deliver messages.
  document.querySelectorAll('.site-form').forEach((form) => {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const status = form.querySelector('[data-form-status]');
      if (!form.reportValidity()) {
        if (status) status.textContent = 'Please correct the highlighted fields and try again.';
        return;
      }
      const submit = form.querySelector('button[type="submit"]');
      const originalText = submit.textContent;
      submit.disabled = true;
      submit.textContent = 'Sending…';
      if (status) status.textContent = 'Sending your message securely…';
      try {
        const response = await fetch(form.action, {
          method: 'POST',
          body: new FormData(form),
          headers: { 'Accept': 'application/json' }
        });
        const result = await response.json();
        if (!response.ok || result.success === 'false' || result.success === false) {
          throw new Error(result.message || 'The message could not be sent.');
        }
        form.reset();
        if (status) status.textContent = 'Thank you. Your message has been submitted. Our team will get back to you.';
      } catch (error) {
        if (status) status.textContent = 'We could not submit the form right now. Please email Maphahagiven@gmail.com or call one of the numbers on our Contact page. ' + error.message;
      } finally {
        submit.disabled = false;
        submit.textContent = originalText;
      }
    });
  });

  // Leaflet interactive map. Map tiles and library are loaded only on the contact page.
  const mapElement = document.querySelector('#location-map');
  if (mapElement && window.L) {
    const map = L.map(mapElement).setView([-26.05, 28.18], 9);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    // Approximate town-centre coordinates are used for orientation; use the address links for exact directions.
    L.marker([-26.211, 28.259]).addTo(map).bindPopup('<strong>Berry’s Central</strong><br>4 Madeley Road, Boksburg<br><a href="https://www.google.com/maps/search/?api=1&query=4+Madeley+Road+Boksburg" target="_blank" rel="noopener">Directions</a>');
    L.marker([-25.999, 28.126]).addTo(map).bindPopup('<strong>Berry’s Suburban</strong><br>50 Lesedi Street, Midrand<br><a href="https://www.google.com/maps/search/?api=1&query=50+Lesedi+Street+Midrand" target="_blank" rel="noopener">Directions</a>');
  }
});
