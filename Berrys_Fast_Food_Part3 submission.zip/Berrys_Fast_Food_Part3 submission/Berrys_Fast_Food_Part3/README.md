
| Part 3.2 – Animation enhancement | Added JavaScript IntersectionObserver reveal effects for menu/gallery content, CSS keyframe animation and reduced-motion accessibility handling. |
# Berry's Fast Food – Part 3: Enhancing Functionality and SEO

## Project overview
A responsive multi-page website for Berry's Fast Food. Part 3 extends the Part 2 HTML/CSS project with JavaScript interactions, menu search and sorting, an accessible gallery lightbox, an interactive location map, validated AJAX forms and SEO files.

## Pages
- `home.html` – welcome page and promotional video.
- `about.html` – restaurant history, mission, vision and team.
- `services.html` – illustrated menu cards with sample prices in South African Rand (R), live search, category filtering and sorting.
- `gallery.html` – responsive food gallery with keyboard-accessible lightbox.
- `enquiry.html` – product, menu, order and service enquiry form.
- `contact.html` – branch details, interactive map and general contact form.

## Part 3 functionality
- **Interactive elements:** accessible accordion panels on Home and About pages.
- **Interactive map:** Leaflet with OpenStreetMap tiles and markers for the Boksburg and Midrand locations. The pins are approximate town-centre positions; the address links provide directions to the supplied street addresses.
- **Animations and transitions:** existing navigation/card/image transitions retained and extended with responsive interaction states.
- **DOM manipulation:** JavaScript updates accordion state, filters/sorts menu cards, updates result counts and opens/closes the gallery lightbox.
- **Image lightbox:** select a gallery image to enlarge it; close using the close button, backdrop or Escape key.
- **Dynamic menu:** search by item name and filter by Burgers, Pap meals or Sides and drinks; sort alphabetically.
- **Menu photographs and pricing:** added meal photographs to menu cards, descriptive image alternative text, and visible sample prices in South African Rand (R). Prices are illustrative for the assignment and should be confirmed or replaced with the restaurant’s actual prices before commercial use.

## Forms and validation
Both forms use native HTML constraints (`required`, `type=email`, `type=tel`, `pattern`, `minlength`, `maxlength`, numeric limits and date input) and JavaScript `reportValidity()` before AJAX submission. Submission uses the FormSubmit AJAX endpoint configured for `Maphahagiven@gmail.com`. The recipient must activate FormSubmit using its first confirmation email before live delivery will work. Static hosting cannot securely send email by itself; the external form service handles delivery. If delivery is unavailable, the form displays a fallback contact instruction.

- `enquiry.html` is for product/service questions, orders, catering, pricing and availability. It collects the product/service, quantity/date where applicable and details. The Services page displays illustrative sample prices for the assignment; the enquiry response explains that the team will confirm current prices and availability.
- `contact.html` is for general messages. It collects basic contact details, message type, subject and a full message, then submits those fields to the recipient email through AJAX.

## SEO implementation
- Unique descriptive page titles and meta descriptions on all pages.
- Semantic page structure with one main heading and nested section headings.
- Descriptive image alternative text; responsive image sources retained. SEO-friendly copies of the pap meal image and promotional video are included.
- Internal links connect the menu, enquiry, gallery and contact pages.
- Responsive layouts and mobile viewport settings retained.
- Open Graph title/description metadata added.
- `robots.txt` and `sitemap.xml` created. **Before deployment, replace `YOUR-DEPLOYED-SITE-URL` in both files with the exact public domain.**
- Off-page SEO is supported through shareable pages and social promotion. Backlinks and social media posts require external publication and cannot be created solely within this source-code project. Local SEO content includes Boksburg and Midrand location details.

## External libraries and services
- Leaflet 1.9.4 (loaded from unpkg CDN) for the interactive map.
- OpenStreetMap for map tiles.
- FormSubmit AJAX endpoint for email delivery (recipient activation required).

## Running and testing
Open `home.html` in a modern browser or deploy the folder to a static host. Internet access is required for the map library, map tiles and AJAX form service. Test all six pages on desktop, tablet and mobile widths. Test menu filtering/sorting, accordion controls, gallery keyboard interactions, map markers, invalid form inputs and successful form delivery after the recipient activates FormSubmit.

## Deployment checklist
1. Push the complete project folder to the GitHub repository.
2. Deploy the folder using Netlify or GitHub Pages.
3. Replace `YOUR-DEPLOYED-SITE-URL` in `robots.txt` and `sitemap.xml` with the deployed domain.
4. Submit a test enquiry and contact message; activate the FormSubmit confirmation email first.
5. Add the deployed sitemap URL to Google Search Console if available.
6. Capture desktop, tablet and mobile screenshots as evidence.

## Changelog
| Version | Detailed changes |
|---|---|
| Part 1 | Created the initial Berry's Fast Food HTML pages and media assets. |
| Part 2 | Added shared external CSS, responsive layouts, semantic HTML, navigation states, responsive image variants, accessible labels and location links. |
| Part 3.1 – SEO | Added unique page titles, meta descriptions, Open Graph metadata, descriptive image filenames, internal links, `robots.txt` and `sitemap.xml` (deployment URL replacement required). |
| Part 3.2 – JavaScript | Added accordion interactions, live menu search, category filtering, alphabetical sorting, result counts, DOM updates and an accessible image lightbox with Escape/backdrop closing. |
| Part 3.3 – Map | Added a Leaflet/OpenStreetMap map with markers and directions links for the two listed branches. |
| Part 3.4 – Forms | Added a dedicated `enquiry.html` page and differentiated it from the general contact form. Added HTML5 constraints, client-side validation, error/status messages and AJAX email submission via FormSubmit. |
| Part 3.5 – Menu presentation | Added meal photographs, descriptive alt text and sample prices in South African Rand to the Services page. Added responsive menu-card styling and updated the README. Sample prices are clearly identified as illustrative and must be confirmed before commercial use. |
| Part 3.6 – Documentation | Updated this README with implementation details, testing guidance, deployment steps and external service requirements. |

## Suggested commit messages
- `feat: add interactive menu search and filtering`
- `feat: add gallery lightbox and accordion interactions`
- `feat: add Leaflet map for restaurant locations`
- `feat: add validated AJAX enquiry and contact forms`
- `feat: implement page metadata and SEO crawler files`
- `docs: document Part 3 implementation and changelog`

The interactive map uses Leaflet 1.9.4 and OpenStreetMap tiles on the Contact page. The map markers are approximate orientation points, not verified business geocodes. The gallery lightbox supports click, keyboard activation, Escape and backdrop closing.
